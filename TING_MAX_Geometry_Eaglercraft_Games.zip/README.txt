TING MAX: original standalone Music + Unstable SMP Theater + Library, with BedWars added.
Open index.html to view. For reliable game loading, host the whole folder on a static website host.
BedWars is a separate browser game project, not the original Roblox BedWars.
